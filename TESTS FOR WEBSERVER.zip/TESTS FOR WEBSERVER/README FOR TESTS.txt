The tests use 5 files smallfile.txt(5KB), mediumfile.txt(50KB) largefile.txt(100KB) and monsterfile.txt (50MB)

